#!pip install pyttsx3
#import your libraries
#for text
import pyttsx3
#using webcam
import cv2
#playing mp3s
from playsound import playsound
#the room class
from Room import Room
#for waiting
from time import sleep
#for the drawing along with the " + name + " pyscho room
import pygame, sys
from pygame.locals import *
#for deciding whether or not to let you in the freedom part 
import random
#making " + name + " in psycho room
class Sprite(pygame.sprite.Sprite):
    def __init__(self, pos):
        self.rect = pygame.Rect(pos[0], pos[1], 16, 16)
        self.image = pygame.image.load(name + "CRAZY.png")
pygame.init()
######################################################
#initiallizing some variables
hasHammer = False 
engine = pyttsx3.init("sapi5")
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
vid = cv2.VideoCapture(0)

name = input("Hey, solo traveller! What's your name? ")

#for drawing-- COPIED FROM lemastertech
#letting you draw + final endings
def drawTime():
    #setting up the drawing screen
    fps = 60
    timer = pygame.time.Clock()
    width = 800
    height = 600
    screen = pygame.display.set_mode((width, height))
    pygame.display.set_caption('show ur skills')
    run = True
    activeSize = 15
    activeColor = "black"
    painting = []
    screen.fill("white")
    #letting you ACTUALLY draw
    while run:
        mouse = pygame.mouse.get_pos()
        timer.tick(180)
        #pygame.draw.circle(screen, activeColor, mouse, activeSize)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if pygame.mouse.get_pressed()[0]:
                painting.append((activeColor, mouse, activeSize))
                for i in range(len(painting)):
                    pygame.draw.circle(screen, painting[i][0], painting[i][1], painting[i][2])
        pygame.display.flip()
    
    pygame.quit()
    #randomly decides whether or not your drawing was good enough. 0 means it was bad and 1 means it was good
    goodOrBad = random.randint(0, 2)
    if goodOrBad == 0:
        engine.say("They didn't like your drawing. l o l. try again some other time!! You deserve to see what's out there.")
        engine.runAndWait()
    else:
        #unlocks the SOUTH exit (matches with SOUTHbookshelf
        engine.say("Welcome to the pure bliss that is free will! Exit south now.")
        engine.runAndWait()
        currentRoom.locked[0] = False
#one of the final rooms
def inDaCloset(hasHammer_):
    engine.say(name + " stupidly entered the closet room. She is forced to meet eye to eye in the mirror with the most vile creature imaginable...")
    engine.runAndWait()
    ret, frame = vid.read()
    #takes pic of u, proceeds to have a man scream at how you look
    cv2.imshow('frame', frame)
    vid.release()
    sleep(6)
    playsound("man-screaming-01.mp3")
    sleep(2)
    #the computer's last words to you depends on whether or not the hammer was picked up in room 4. it doesnt REALLY make a difference though
    if hasHammer_:
        engine.say(name + " has to watch this monster in front of her for eternity. She reaches for the hammer in her inventory, but she can't find it because the closet is so dark. theres no getting out. she goes crazy and  breaks the glass in the mirror.")
        engine.runAndWait()
    else:
        engine.say(name + " has to watch this monster in front of her for eternity. If only she had a hammer with her. theres no getting out. she goes crazy and  breaks the glass in the mirror.")
        engine.runAndWait()
    playsound("Big-Glass-Breaking-Combo-www.fesliyanstudios.com.mp3")
    sleep(1)
    exit()

#one of the final rooms
def youWentUpStairs():
    #makes your screen black and sets a little scene making you jump of the building.. this was totally copied from stanley's parable 
    DISPLAYSURF = pygame.display.set_mode((400, 300),pygame.FULLSCREEN)
    engine.say("You ungrateful little shit! Look at you. You couldve had all the freedom in the world-- you could have had what everyone wants: pure bliss. no boredom. constant pleasure. a real meaning to life. But, since you want to act like I havent led you all the way to true happiness, we're here. And now you have no control.")
    engine.runAndWait()
    playsound("steps-on-wooden-stairs-90107.mp3")
    engine.say("look at us now. We're at the top of the staircase, and theres nothing you can say or do to stop what is about to happen. this is what it's really like to have no free will.")
    engine.runAndWait()
    playsound("SF-scream-female-5.mp3")
    playsound("massive-thump-116359.mp3")
    playsound("loud-female-scream-41894.mp3")
    engine.say("and now you are dead, and everyone will think you did this on your own. good. maybe next time you will listen.")
    engine.runAndWait()
    sleep(5)
    pygame.quit()
    exit()

#one of the final rooms
def youArePSYCHO():
    #makes the screen (pillow room) and a sprite (crazy " + name + "). also plays some sound to mock you
    lor = Sprite([16, 16])
    pygame.event.get()
    scrn = pygame.display.set_mode((1350, 1000))
    pygame.event.get()
    pygame.display.set_caption('psycho')
    pygame.event.get()
    imp = pygame.image.load("realcrayz.png").convert()
    pygame.event.get()
    scrn.blit(imp, (0, 0))
    pygame.event.get()
    scrn.blit(lor.image, lor.rect)
    pygame.event.get()
    pygame.display.flip()
    pygame.event.get()
    engine.say(name + " clearly couldn't bear to imagine her own freedom. She willingly put herself in a pillow room. She let us put a straightjacket on her. Since this is what she wants, I will obviously provide it for her. " + name + ", I hope you have fun being far too aware for your entire life. Every little micro bug you feel on your skin, you will be aware of. Every cicada noise you hear will be like a siren to your ears. You will be conscious of every beat your heart makes, of every breath you breathe in and out. The straightjacket on your skin will bleed into you. It will be a second skin. Years from now, you will see a dark demon in the confines of your pillow room. Is it real? Is it not? We know it isn't, but you will be forced to play with it for your entire life as it will be your only companion.")
    pygame.event.get()
    engine.runAndWait()
    pygame.event.get()
    playsound("door-closing-door-closed-6006.mp3")
    pygame.event.get()
    scrn.fill([0,0,0])
    pygame.event.get()
    pygame.display.flip()
    pygame.event.get()
    sleep(1)
    exit()
def freedom():
    while True:
        engine.say("You fool! What is freedom? Why would you want such a thing?")
        engine.runAndWait()
        sleep(2)
        engine.say("be smarter next time. Freedom and free will do not truly exist. You can never truly be mentally free.")
        engine.runAndWait()

# creates the rooms
def createRooms():
# makes rooms, exits, grabbables, items, for each room
# currentRoom is the room the player is currently in (can be ANY of the rooms)
# since it needs to be changed in the main part of the
# program, it must be global
    global currentRoom
    # create the rooms and give them meaningful names
    r1 = Room("Room 1")
    r2 = Room("Room 2")
    r3 = Room("Room 3")
    r4 = Room("Room 4")
    secretRoom = Room("Underground Room")
    r5 = Room("Room 5")
    closet = Room("Closet Room")
    outside = Room("outside")
    psycho = Room("PSYCHO")
    stair = Room("stairs")
    freedom = Room("freedom")
    # add exits to room 1
    r1.addExit("west", r2, False)
    r1.addExit("south", r4,  False)
    r1.addExit("southeast", r5, True)
    # add grabbables to room 1
    r1.addGrabbable("pen")
    # add items to room 1
    r1.addItem("chair", "Yikes, this thing is old.")
    r1.addItem("writing_desk", "Can you tell a raven from a writing desk? The only thing on here is a pen...")
    # add exits to room 2
    r2.addExit("east", r1,  False)
    r2.addExit("south", r3, False)
    # add items to room 2
    r2.addItem("rug", "rugs are so outdated. We need to throw it out. There's literally shit stains...")
    r2.addItem("wall_art", "hmm, maybe you should read what's on this?")
    # add exits to room 3
    r3.addExit("south", outside, True)
    r3.addExit("east", r4, False)
    r3.addExit("north", r2, False)
    # add items to room 3
    r3.addItem("jukebox", "does this thing work?")
    r3.addItem("southBookshelf", "cool")
    #add exits to room 4
    r4.addExit("south", psycho, True)
    r4.addExit("west", r3, False)
    r4.addExit("north", r1, False)
    # add items to room 3
    r4.addItem("junkbox", "Gosh, the only thing here that isn't trash is a hammer.")
    # add grabbables to room 4
    r4.addGrabbable("hammer")
    #add exits to room 5
    r5.addExit("north", r1, False)
    r5.addExit("closet", closet, True)
    #add "exits" to outside
    outside.addExit("stairs", stair, False)
    outside.addExit("freedom", freedom, False)
    # set room 1 as the current room at the beginning
    # of the game
    currentRoom = r1
######################################################
#following geeksforgeeks' orders

# START THE GAME!!!
inventory = [] # nothing in inventory...yet
createRooms() # add the rooms to the game
#pairs that the MAN voice would approve of
goodExitPairs = {
    "Room 1": "Room 2",
    "Room 2": "Room 3",
    "Room 4": "Room 5",
    "Room 4": "Room 3",
    "Room 3": "Room 1",
    "Room 1": "Room 4",
    "Room 3": "outside",
    }
#pairs that the WOMAN voice encourages
badExitPairs = {
    "Room 3": "Room 4",
    "Room 5": "closet",
    "outside": "stairs",
    "Room 4": "PSYCHO",
    "Room 2": "underground",
    }
#if in this room, the intro will be the value of the room
currentRoomsKeyThingsToSayValue = {
        "Room 1": [name + " sees two doors right now: one facing west and one facing south.. well, there is one facing southeast-ish, but that one should be locked anyway. " + name + ", because she is a smart cookie, will walk through the WEST door", "While " + name + " CAN go through the west door, she recognizes that she has her own free will and decides to go through the south door."],
        "Room 2": ["This room is quite boring. There is nothing to see here.", "Come on, Tyler, we both know this room has some super secret stuff! " + name + "... explore"],
        "Room 3": ["This room is integral to your freedom. There is a bookshelf. What is on the bookshelf will lead you to everlasting free will! You just need to figure out how to get past it... I suggest looking around room 1 if you haven't", "Yeah, the shelf is cool and all. There's so much you've yet to explore, though!"],
        "Room 4": ["NO!!! GO BACK!! Please trust me.", "I LOVE this room. Do a little lookaround for a secret door. It's my personal favorite room."],
        "Room 5":["Oh my god, what are you doing in here! You shouldn't be here; it is so dangerous. get out. do not enter the closet.", "I wonder what you can find in the closet?"],
        "Closet Room":["You dumb little shit", "Wow! So roomy in here. I'm sure you'll love your life here."],
        "outside":["Yes! Choose freedom! You've gotten this far.. please don't go up the stairs. Accept your happiness while you still can.", "Are you really about to let a random man tell you what to do? Don't you really want to explore the stairs, " + name + "?"],
        "PSYCHO":["Girl, come on. After all we've been through?", "Imagine actually following what I tell you to do."],
        "stairs":["You had one job!! Not even, really. You just had to do nothing. You had all the freedom in the world in your hands, and now it's gone.", "Honestly, he has a point. This is really embarassing for you"]
    }
#if you didnt listen to the man, the room you're in will decide what the man says to you
didntListenToGood = {
        "Room 1": "One mistake is ok. Try not to make any more, girly pop!",
        "Room 2": "bruh",
        "Room 3": "Not only do you look young, but you behave like a child too! Grow up a little and listen to someone who is obviously trying to help you out.",
        "Room 4": "Listening to me will really help you in the future",
        "Underground Room":"I can't believe you found this. Oh GOD.",
        "Room 5":"The blue hair dye really must be getting to you. What a shame!",
        "Closet Room":"Ok, miss doesn't follow the rules. Have fun making no decisions for the rest of your life.",
        "outside":"",
        "PSYCHO":"Clearly you know nothing. Now you are trapped in your head for eternity.",
        "stairs":"step, step, step, step, step.. I dont think you want to know what's next."
    }
#if you did listen to man, the room you're in will decide what the man says to you
didListenToGood = {
        "Room 1": "we really are off to a good start",
        "Room 2": "you really rock that purple hair, girl!",
        "Room 3": "i really enjoy listening to a cat's meow almost as much as I enjoy the trust you have in me.",
        "Room 4": "One step closer to paradise. I'm happy to see we can sit here. That we can finally be friends. I know you've wanted a friend for so long, " + name + ". That's why you are still here. You enjoy my company. Honestly, " + name + ", I enjoy yours too. I'm really glad we can explore this place together. As friends for life. I will never let you down.",
        "Underground Room":"shouldnt get this msg",
        "Room 5":"",
        "Closet Room":"",
        "outside":"Free at last! Don't pay any mind to the staircase, " + name + ". Stay here. Stay free",
        "PSYCHO":"shouldnt get this msg",
        "stairs":"you shouldnt get this msg"
    }
#intro
engine.say(name + " spent her whole life thinking computationally. This means she very well knows that she MUST listen to a higher power. Bad things will happen if she doesnt....")
engine.runAndWait()
engine.say(name + " also knows the difference between good and bad powers. This separation will guarantee her survival in this place.")
engine.runAndWait()
#initislizing some variables
pastRoom = "X"
wasLocked = False
verb = ""
# play forever (well, at least until the player dies or asks to
#  quit)
while (True):
    #lines 270-289 just need to initially check some things
    #being in room 4 automatically changes room 5 to be unlocked
    if currentRoom.name == "Room 4":
        roomToChange = currentRoom.exitLocations[2]
        roomToChange.locked[2] = False
    #if you have the hammer, the computer needs to know to check
    if "hammer" in inventory:
        hasHammer = True
        #if in stair room, call the function for that room ending
    if(currentRoom.name == "stairs"):
        youWentUpStairs()
    #if in psycho room, call the function for that room ending
    if(currentRoom.name == "PSYCHO"):
        youArePSYCHO()
    #the person will say something to you based on whether or not you chose to listen to him or not. if you listened, it gives you something from the didlistentogood dictionary.. otherwise, from the didntlistentogood dictionary
    if(pastRoom, currentRoom.name) in goodExitPairs.items():
        engine.say(didListenToGood[pastRoom])
        engine.runAndWait()
    elif((pastRoom, currentRoom.name) in badExitPairs.items()):
        engine.say(didntListenToGood[pastRoom])
        engine.runAndWait()
        
    # set the status so the player has situational awareness
    # the status has room and inventory information
    status = "{}\nYou are carrying: {}\n".format(currentRoom, inventory)

    # if the current room is None, then the player is dead
    # this only happens if the player goes south when in room 4

    # display the status
    print("=========================================")
    #based on the current room, every time you enter a room you will hear these things from both the "good" and "bad" power!
    if (verb == "go" and not wasLocked) or verb == "":
        for i in currentRoomsKeyThingsToSayValue:
            if i in currentRoom.name:
                engine.say(currentRoomsKeyThingsToSayValue[currentRoom.name][0])
                engine.runAndWait()
                engine.setProperty('voice', voices[1].id)
                engine.say(currentRoomsKeyThingsToSayValue[currentRoom.name][1])
                engine.runAndWait()
                engine.setProperty('voice', voices[0].id)
    print(status)

    # prompt for player input
    # the game supports a simple language of <verb> <noun>
    # valid verbs are go, look, and take
    # valid nouns depend on the verb
    action = input("What to do? ")

    #set the user's input to lowercase to make it easier to
    #compare the verb and noun to known values
    action = action.lower()
    #if youre in the fifth room and want to go to closet, then you call the closet room ending
    if(currentRoom.name == "Room 5" and action.lower() == "go closet"):
        inDaCloset(hasHammer)
    if(currentRoom.name == "outside" and action.lower() == "go freedom"):
        freedom()
    # exit the game if the player wants to leave (supports
    #  quit, exit, and bye)
    if (action == "quit" or action == "exit" or action == "bye"):
        break
    #changing item description if you take the grabbable on the item
    if action == "take hammer" and currentRoom.name == "Room 4":
        currentRoom.itemDescriptions[0] = "A box full of JUNK."
    if action == "take pen" and currentRoom.name == "Room 1":
        currentRoom.itemDescriptions[1] = "Could you tell a raven from a writing desk?"
    #if you try to go south in room 4 (go to psycho room), one will plead w you and another will encourage you. You then can enter a password and if it is corrent, the door will become unlocked. if its wrong you will be told the password was wrong
    if action == "go south" and currentRoom.name == "Room 4":
        engine.say("I'm begging you not to even try to get in here. You'll regret it.")
        engine.runAndWait()
        engine.setProperty('voice', voices[1].id)
        engine.say("Who would be so controlling? If you have a password, it'll let you in... hint:room 2")
        engine.setProperty('voice', voices[0].id)
        engine.runAndWait()
        password = input("Enter the password ")
        if password == "fre3WiLl":
            response = "door unlocked"
            currentRoom.locked[0] = False
        else:
            response = "not the password"
        
    # set a default response
    response = "I don't understand. Try verb noun. Valid verbs are go, look, take, draw, and read."
    # split the user input into words (words are separated by
    #  spaces)
    #if you want to read the wall_art then you are given the password.
    if action == "read wall_art":
        response = "fre3WiLl\nRemember this exactly.. you may need it later"
        
    words = action.split()

    # the game only understands two word inputs
    if (len(words) == 2):
        # isolate the verb and noun
        verb = words[0]
        noun = words[1]

        # the verb is: go
        if (verb == "go"):
            # set a default response
            response = "Invalid exit."

            # just super quickly as a default make the pastroom equal to the name of the current room. we only use it in the beginning of the loop, and pastroom must only be the actual other room you were previously in if you have JUST changed the room
            pastRoom = currentRoom.name
            # check for valid exits in the current room
            for i in range(len(currentRoom.exits)):
                # a valid exit is found
                if (noun == currentRoom.exits[i] and not currentRoom.locked[i]):
                    # change the current room to the one
                    #  that is associated with the specified
                    #  exit
                    #here we must make sure that the past room gets the room from rn's value before the room changes
                    pastRoom = currentRoom.name
                    #change currentroom to the room you wanna go to
                    currentRoom =  currentRoom.exitLocations[i]
                    #since it changed the room mustve not been locked
                    wasLocked = False

                    # set the response (success)
                    response = "Room changed."

                    # no need to check any more exits
                    break
                elif currentRoom.locked[i]:
                    #play a locked door sound and store it that the variable was in fact locked. need this so our man doesnt talk EVERY time we try to leave. super annoying to hear the same monologue over and over
                    wasLocked = True
                    playsound("E4DV6Q2-door-lock-locked.mp3")
        # the verb is: look
        elif (verb == "look"):
            pastRoom = currentRoom.name
            # set a default response
            response = "I don't see that item."
            #if you want to look at the bookshelf while you have the pen you will be allowed to try to draw the become free
            if (noun == "southbookshelf" and currentRoom.name == "Room 3") and ("pen" in inventory):
                response = "meow"
                engine.say("You find a blank piece of paper and decide to make a lovely doodle on it. Who knows, maybe you could get something special if it's pretty enough! X out when your doodle is done.")
                engine.runAndWait()
                drawTime()
            #if no pen, you will be indirectly prompted to get the pen
            elif (noun == "southbookshelf" and currentRoom.name == "Room 3"):
                response = "Um, maybe try expanding your inventory first. Do you even listen to your narrators?"
            # check for valid items in the current room
            for i in range(len(currentRoom.items)):
                # a valid item is found
                if (noun == currentRoom.items[i]):
                    # set the response to the item's
                    #  description
                    response = currentRoom.itemDescriptions[i]
                    # no need to check any more items
                    break
        # the verb is: take
        elif (verb == "take"):
            pastRoom = currentRoom.name
            # set a default response
            response = "I don't see that item."
            # check for valid grabbable items in the current
            #  room
            for grabbable in currentRoom.grabbables:
                # a valid grabbable item is found
                if (noun == grabbable):
                    # add the grabbable item to the player's
                    #  inventory
                    inventory.append(grabbable)
                    # remove the grabbable item from the
                    #  room
                    currentRoom.delGrabbable(grabbable)
                    # set the response (success)
                    response = "Item grabbed."
                    # no need to check any more grabbable
                    #  items
                    break

    # display the response
    print("\n{}".format(response))

